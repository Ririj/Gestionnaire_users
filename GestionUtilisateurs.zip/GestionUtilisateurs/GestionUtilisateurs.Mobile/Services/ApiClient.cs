using System.Net;
using System.Text;
using System.Text.Json;

namespace GestionUtilisateurs.Mobile.Services;

/// <summary>Client HTTP unique : ajoute le jeton Bearer, convertit les erreurs en ApiException.</summary>
public class ApiClient
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    private readonly HttpClient _http;
    private readonly SessionService _session;

    public event Action? SessionExpired;

    public ApiClient(SessionService session)
    {
        _session = session;
        _http = new HttpClient
        {
            BaseAddress = new Uri(ApiConfig.BaseUrl),
            Timeout = TimeSpan.FromSeconds(20)
        };
    }

    public async Task<T> SendAsync<T>(HttpMethod method, string url, object? body = null, bool authenticated = true)
    {
        var raw = await SendRawAsync(method, url, CreateJson(body), authenticated);
        var result = JsonSerializer.Deserialize<T>(raw, JsonOptions);
        return result ?? throw new ApiException("Reponse vide du serveur.");
    }

    public Task SendAsync(HttpMethod method, string url, object? body = null, bool authenticated = true)
        => SendRawAsync(method, url, CreateJson(body), authenticated);

    public Task<string> PostFormAsync(string url, Dictionary<string, string> form)
        => SendRawAsync(HttpMethod.Post, url, new FormUrlEncodedContent(form), authenticated: false);

    public T Deserialize<T>(string json)
        => JsonSerializer.Deserialize<T>(json, JsonOptions) ?? throw new ApiException("Reponse vide du serveur.");

    private static HttpContent? CreateJson(object? body)
        => body == null ? null : new StringContent(JsonSerializer.Serialize(body, JsonOptions), Encoding.UTF8, "application/json");

    private async Task<string> SendRawAsync(HttpMethod method, string url, HttpContent? content, bool authenticated)
    {
        using var request = new HttpRequestMessage(method, url) { Content = content };

        if (authenticated)
        {
            var token = await _session.GetValidTokenAsync();
            if (token == null)
            {
                SessionExpired?.Invoke();
                throw new ApiException("Session expiree. Veuillez vous reconnecter.", 401);
            }
            request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
        }

        HttpResponseMessage response;
        try
        {
            response = await _http.SendAsync(request);
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException)
        {
            throw new ApiException("Impossible de joindre le serveur. Verifiez que l'API est demarree et l'adresse dans ApiConfig.cs.");
        }

        var text = await response.Content.ReadAsStringAsync();
        if (response.IsSuccessStatusCode) return text;

        if (response.StatusCode == HttpStatusCode.Unauthorized && authenticated)
        {
            _session.Clear();
            SessionExpired?.Invoke();
            throw new ApiException("Session expiree. Veuillez vous reconnecter.", 401);
        }

        if (response.StatusCode == HttpStatusCode.Forbidden)
            throw new ApiException("Action reservee aux administrateurs.", 403);

        throw new ApiException(ExtractMessage(text) ?? $"Erreur serveur ({(int)response.StatusCode}).", (int)response.StatusCode);
    }

    private static string? ExtractMessage(string json)
    {
        if (string.IsNullOrWhiteSpace(json)) return null;
        try
        {
            using var doc = JsonDocument.Parse(json);
            foreach (var name in new[] { "message", "error_description", "Message" })
            {
                if (doc.RootElement.TryGetProperty(name, out var value) && value.ValueKind == JsonValueKind.String)
                    return value.GetString();
            }
        }
        catch (JsonException) { }
        return null;
    }
}
