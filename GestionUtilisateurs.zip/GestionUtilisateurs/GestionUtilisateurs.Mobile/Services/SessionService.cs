using System.Globalization;
using GestionUtilisateurs.Mobile.Models;

namespace GestionUtilisateurs.Mobile.Services;

/// <summary>
/// Persistance de la session : le jeton est stocke dans le SecureStorage du telephone
/// et relu au demarrage de l'application.
/// </summary>
public class SessionService
{
    private const string TokenKey = "access_token";
    private const string ExpiryKey = "token_expires_utc";

    public UserDto? CurrentUser { get; set; }

    public async Task SaveAsync(string token, DateTime expiresUtc)
    {
        await SetAsync(TokenKey, token);
        await SetAsync(ExpiryKey, expiresUtc.ToString("O", CultureInfo.InvariantCulture));
    }

    /// <summary>Retourne le jeton s'il existe et n'est pas expire, sinon null.</summary>
    public async Task<string?> GetValidTokenAsync()
    {
        var token = await GetAsync(TokenKey);
        var expiry = await GetAsync(ExpiryKey);

        if (string.IsNullOrEmpty(token) ||
            !DateTime.TryParse(expiry, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var expiresUtc) ||
            expiresUtc <= DateTime.UtcNow)
        {
            Clear();
            return null;
        }

        return token;
    }

    public void Clear()
    {
        CurrentUser = null;
        try { SecureStorage.Default.Remove(TokenKey); SecureStorage.Default.Remove(ExpiryKey); }
        catch { /* stockage indisponible */ }
        Preferences.Default.Remove(TokenKey);
        Preferences.Default.Remove(ExpiryKey);
    }

    private static async Task SetAsync(string key, string value)
    {
        try { await SecureStorage.Default.SetAsync(key, value); }
        catch { Preferences.Default.Set(key, value); } // repli si le stockage securise est indisponible
    }

    private static async Task<string?> GetAsync(string key)
    {
        try
        {
            var value = await SecureStorage.Default.GetAsync(key);
            if (value != null) return value;
        }
        catch { /* repli ci-dessous */ }
        var fallback = Preferences.Default.Get<string?>(key, null);
        return fallback;
    }
}
