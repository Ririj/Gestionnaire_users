namespace GestionUtilisateurs.Mobile.Services;

public static class ApiConfig
{
    // Emulateur Android : 10.0.2.2 designe l'ordinateur hote.
    // Telephone physique : remplacer par l'adresse IP locale du PC (ex. http://192.168.1.20:5000/).
    public const string EmulatorUrl = "http://10.0.2.2:5000/";
    public const string PhysicalDeviceUrl = "http://192.168.1.20:5000/";

    public static string BaseUrl =>
        DeviceInfo.DeviceType == DeviceType.Virtual ? EmulatorUrl : PhysicalDeviceUrl;
}
