using GestionUtilisateurs.Mobile.Models;

namespace GestionUtilisateurs.Mobile.Services;

public class UserService
{
    private readonly ApiClient _api;
    private readonly SessionService _session;

    public UserService(ApiClient api, SessionService session)
    {
        _api = api;
        _session = session;
    }

    // Profil de l'utilisateur connecte
    public async Task<UserDto> GetMeAsync()
    {
        var me = await _api.SendAsync<UserDto>(HttpMethod.Get, "api/account/me");
        _session.CurrentUser = me;
        return me;
    }

    public async Task<UserDto> UpdateMeAsync(UpdateProfileDto dto)
    {
        var me = await _api.SendAsync<UserDto>(HttpMethod.Put, "api/account/me", dto);
        _session.CurrentUser = me;
        return me;
    }

    public Task ChangePasswordAsync(ChangePasswordDto dto)
        => _api.SendAsync(HttpMethod.Post, "api/account/changePassword", dto);

    // CRUD (administrateur)
    public Task<List<UserDto>> GetAllAsync()
        => _api.SendAsync<List<UserDto>>(HttpMethod.Get, "api/users");

    public Task<UserDto> GetAsync(string id)
        => _api.SendAsync<UserDto>(HttpMethod.Get, $"api/users/{Uri.EscapeDataString(id)}");

    public Task<UserDto> CreateAsync(CreateUserDto dto)
        => _api.SendAsync<UserDto>(HttpMethod.Post, "api/users", dto);

    public Task<UserDto> UpdateAsync(string id, UpdateUserDto dto)
        => _api.SendAsync<UserDto>(HttpMethod.Put, $"api/users/{Uri.EscapeDataString(id)}", dto);

    public Task DeleteAsync(string id)
        => _api.SendAsync(HttpMethod.Delete, $"api/users/{Uri.EscapeDataString(id)}");
}
