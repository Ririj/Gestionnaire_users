using GestionUtilisateurs.Mobile.Models;

namespace GestionUtilisateurs.Mobile.Services;

public class AuthService
{
    private readonly ApiClient _api;
    private readonly SessionService _session;

    public AuthService(ApiClient api, SessionService session)
    {
        _api = api;
        _session = session;
    }

    /// <summary>Authentification OAuth2 (grant_type=password) sur le point /Token de l'API.</summary>
    public async Task LoginAsync(string email, string password)
    {
        var raw = await _api.PostFormAsync("Token", new Dictionary<string, string>
        {
            ["grant_type"] = "password",
            ["username"] = email.Trim(),
            ["password"] = password
        });

        var token = _api.Deserialize<TokenResponse>(raw);
        if (string.IsNullOrEmpty(token.Access_Token))
            throw new ApiException("Reponse d'authentification invalide.");

        // expires_in est en secondes ; marge de securite de 1 minute
        var expires = DateTime.UtcNow.AddSeconds(Math.Max(token.Expires_In - 60, 60));
        await _session.SaveAsync(token.Access_Token, expires);
    }

    public Task RegisterAsync(RegisterDto dto)
        => _api.SendAsync(HttpMethod.Post, "api/account/register", dto, authenticated: false);

    public async Task<bool> HasSessionAsync() => await _session.GetValidTokenAsync() != null;

    public void Logout() => _session.Clear();
}
