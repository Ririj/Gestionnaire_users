using GestionUtilisateurs.Mobile.Services;
using GestionUtilisateurs.Mobile.Views;

namespace GestionUtilisateurs.Mobile;

public partial class AppShell : Shell
{
    public AppShell(ApiClient api)
    {
        InitializeComponent();

        ApplyRole(false);

        Routing.RegisterRoute("register", typeof(RegisterPage));
        Routing.RegisterRoute("useredit", typeof(UserEditPage));

        // Session expiree (401) : retour a l'ecran de connexion
        api.SessionExpired += () =>
            MainThread.BeginInvokeOnMainThread(async () =>
            {
                ApplyRole(false);
                await GoToAsync("//login");
            });
    }

    /// <summary>L'onglet "Utilisateurs" (CRUD) n'est visible que pour un administrateur.</summary>
    public void ApplyRole(bool isAdmin)
    {
        UsersTab.IsVisible = isAdmin;
    }
}
