using GestionUtilisateurs.Mobile.ViewModels;

namespace GestionUtilisateurs.Mobile.Views;

public partial class RegisterPage : ContentPage
{
    public RegisterPage(RegisterViewModel vm)
    {
        InitializeComponent();
        BindingContext = vm;
    }
}
