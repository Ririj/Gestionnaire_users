using GestionUtilisateurs.Mobile.Models;
using GestionUtilisateurs.Mobile.ViewModels;

namespace GestionUtilisateurs.Mobile.Views;

public partial class UsersPage : ContentPage
{
    private readonly UsersViewModel _vm;

    public UsersPage(UsersViewModel vm)
    {
        InitializeComponent();
        BindingContext = _vm = vm;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await _vm.LoadCommand.ExecuteAsync(null);
    }

    private async void OnSelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (e.CurrentSelection.FirstOrDefault() is UserDto user)
        {
            ((CollectionView)sender!).SelectedItem = null;
            await _vm.OpenAsync(user);
        }
    }
}
