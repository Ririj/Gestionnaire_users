using GestionUtilisateurs.Mobile.ViewModels;

namespace GestionUtilisateurs.Mobile.Views;

public partial class UserEditPage : ContentPage
{
    public UserEditPage(UserEditViewModel vm)
    {
        InitializeComponent();
        BindingContext = vm;
    }
}
