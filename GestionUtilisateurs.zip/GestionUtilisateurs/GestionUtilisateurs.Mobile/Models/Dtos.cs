namespace GestionUtilisateurs.Mobile.Models;

// Transfer Objects cote client : miroir des DTO de l'API.

public class UserDto
{
    public string Id { get; set; } = "";
    public string Email { get; set; } = "";
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string? PhoneNumber { get; set; }
    public DateTime CreatedAt { get; set; }
    public List<string> Roles { get; set; } = new();
    public bool IsAdmin { get; set; }

    public string FullName => $"{FirstName} {LastName}".Trim();
    public string RoleLabel => IsAdmin ? "Administrateur" : "Utilisateur";
}

public class RegisterDto
{
    public string Email { get; set; } = "";
    public string Password { get; set; } = "";
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string? PhoneNumber { get; set; }
}

public class CreateUserDto : RegisterDto
{
    public bool IsAdmin { get; set; }
}

public class UpdateUserDto
{
    public string Email { get; set; } = "";
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string? PhoneNumber { get; set; }
    public bool IsAdmin { get; set; }
}

public class UpdateProfileDto
{
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string? PhoneNumber { get; set; }
}

public class ChangePasswordDto
{
    public string OldPassword { get; set; } = "";
    public string NewPassword { get; set; } = "";
}

public class TokenResponse
{
    public string? Access_Token { get; set; }
    public int Expires_In { get; set; }
}
