using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using GestionUtilisateurs.Mobile.Models;
using GestionUtilisateurs.Mobile.Services;

namespace GestionUtilisateurs.Mobile.ViewModels;

[QueryProperty(nameof(UserId), "id")]
public partial class UserEditViewModel : BaseViewModel
{
    private readonly UserService _users;

    [ObservableProperty] private string userId = "";

    [ObservableProperty] private string title = "Nouvel utilisateur";
    [ObservableProperty] private bool isNew = true;
    [ObservableProperty] private bool isExisting;

    [ObservableProperty] private string email = "";
    [ObservableProperty] private string firstName = "";
    [ObservableProperty] private string lastName = "";
    [ObservableProperty] private string phoneNumber = "";
    [ObservableProperty] private string password = "";
    [ObservableProperty] private bool isAdmin;

    public UserEditViewModel(UserService users)
    {
        _users = users;
    }

    partial void OnUserIdChanged(string value)
    {
        IsNew = string.IsNullOrEmpty(value) || value == "new";
        IsExisting = !IsNew;
        Title = IsNew ? "Nouvel utilisateur" : "Modifier l'utilisateur";

        if (!IsNew)
            _ = RunAsync(async () => Apply(await _users.GetAsync(value)));
    }

    [RelayCommand]
    private async Task SaveAsync()
    {
        if (string.IsNullOrWhiteSpace(Email) || string.IsNullOrWhiteSpace(FirstName) || string.IsNullOrWhiteSpace(LastName))
        {
            ErrorMessage = "L'e-mail, le prenom et le nom sont obligatoires.";
            return;
        }

        if (IsNew && string.IsNullOrEmpty(Password))
        {
            ErrorMessage = "Le mot de passe est obligatoire pour un nouvel utilisateur.";
            return;
        }

        var phone = string.IsNullOrWhiteSpace(PhoneNumber) ? null : PhoneNumber.Trim();

        await RunAsync(async () =>
        {
            if (IsNew)
            {
                await _users.CreateAsync(new CreateUserDto
                {
                    Email = Email.Trim(),
                    FirstName = FirstName.Trim(),
                    LastName = LastName.Trim(),
                    PhoneNumber = phone,
                    Password = Password,
                    IsAdmin = IsAdmin
                });
            }
            else
            {
                await _users.UpdateAsync(UserId, new UpdateUserDto
                {
                    Email = Email.Trim(),
                    FirstName = FirstName.Trim(),
                    LastName = LastName.Trim(),
                    PhoneNumber = phone,
                    IsAdmin = IsAdmin
                });
            }

            await Shell.Current.GoToAsync("..");
        });
    }

    [RelayCommand]
    private async Task DeleteAsync()
    {
        var confirmed = await Shell.Current.DisplayAlert(
            "Suppression", $"Supprimer definitivement {FirstName} {LastName} ?", "Supprimer", "Annuler");
        if (!confirmed) return;

        await RunAsync(async () =>
        {
            await _users.DeleteAsync(UserId);
            await Shell.Current.GoToAsync("..");
        });
    }

    private void Apply(UserDto user)
    {
        Email = user.Email;
        FirstName = user.FirstName;
        LastName = user.LastName;
        PhoneNumber = user.PhoneNumber ?? "";
        IsAdmin = user.IsAdmin;
    }
}
