using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using GestionUtilisateurs.Mobile.Models;
using GestionUtilisateurs.Mobile.Services;

namespace GestionUtilisateurs.Mobile.ViewModels;

public partial class RegisterViewModel : BaseViewModel
{
    private readonly AuthService _auth;

    [ObservableProperty] private string firstName = "";
    [ObservableProperty] private string lastName = "";
    [ObservableProperty] private string email = "";
    [ObservableProperty] private string phoneNumber = "";
    [ObservableProperty] private string password = "";
    [ObservableProperty] private string confirmPassword = "";

    public RegisterViewModel(AuthService auth)
    {
        _auth = auth;
    }

    [RelayCommand]
    private async Task RegisterAsync()
    {
        if (string.IsNullOrWhiteSpace(FirstName) || string.IsNullOrWhiteSpace(LastName) ||
            string.IsNullOrWhiteSpace(Email) || string.IsNullOrEmpty(Password))
        {
            ErrorMessage = "Renseignez le prenom, le nom, l'e-mail et le mot de passe.";
            return;
        }

        if (Password != ConfirmPassword)
        {
            ErrorMessage = "Les mots de passe ne correspondent pas.";
            return;
        }

        await RunAsync(async () =>
        {
            await _auth.RegisterAsync(new RegisterDto
            {
                FirstName = FirstName.Trim(),
                LastName = LastName.Trim(),
                Email = Email.Trim(),
                PhoneNumber = string.IsNullOrWhiteSpace(PhoneNumber) ? null : PhoneNumber.Trim(),
                Password = Password
            });

            await AlertAsync("Compte cree", "Vous pouvez maintenant vous connecter.");
            await Shell.Current.GoToAsync("..");
        });
    }
}
