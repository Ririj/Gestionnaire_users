using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.Input;
using GestionUtilisateurs.Mobile.Models;
using GestionUtilisateurs.Mobile.Services;

namespace GestionUtilisateurs.Mobile.ViewModels;

public partial class UsersViewModel : BaseViewModel
{
    private readonly UserService _users;

    public ObservableCollection<UserDto> Users { get; } = new();

    public UsersViewModel(UserService users)
    {
        _users = users;
    }

    [RelayCommand]
    public Task LoadAsync() => RunAsync(async () =>
    {
        var list = await _users.GetAllAsync();
        Users.Clear();
        foreach (var user in list) Users.Add(user);
    });

    [RelayCommand]
    private Task AddAsync() => Shell.Current.GoToAsync("useredit?id=new");

    public Task OpenAsync(UserDto user) => Shell.Current.GoToAsync($"useredit?id={Uri.EscapeDataString(user.Id)}");
}
