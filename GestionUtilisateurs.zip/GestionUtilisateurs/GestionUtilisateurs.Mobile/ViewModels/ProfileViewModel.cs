using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using GestionUtilisateurs.Mobile.Models;
using GestionUtilisateurs.Mobile.Services;

namespace GestionUtilisateurs.Mobile.ViewModels;

public partial class ProfileViewModel : BaseViewModel
{
    private readonly UserService _users;
    private readonly AuthService _auth;

    [ObservableProperty] private string email = "";
    [ObservableProperty] private string firstName = "";
    [ObservableProperty] private string lastName = "";
    [ObservableProperty] private string phoneNumber = "";
    [ObservableProperty] private string roleLabel = "";
    [ObservableProperty] private string createdAt = "";

    [ObservableProperty] private string oldPassword = "";
    [ObservableProperty] private string newPassword = "";

    public ProfileViewModel(UserService users, AuthService auth)
    {
        _users = users;
        _auth = auth;
    }

    [RelayCommand]
    public Task LoadAsync() => RunAsync(async () => Apply(await _users.GetMeAsync()));

    [RelayCommand]
    private async Task SaveAsync()
    {
        if (string.IsNullOrWhiteSpace(FirstName) || string.IsNullOrWhiteSpace(LastName))
        {
            ErrorMessage = "Le prenom et le nom sont obligatoires.";
            return;
        }

        await RunAsync(async () =>
        {
            var me = await _users.UpdateMeAsync(new UpdateProfileDto
            {
                FirstName = FirstName.Trim(),
                LastName = LastName.Trim(),
                PhoneNumber = string.IsNullOrWhiteSpace(PhoneNumber) ? null : PhoneNumber.Trim()
            });
            Apply(me);
            await AlertAsync("Profil", "Modifications enregistrees.");
        });
    }

    [RelayCommand]
    private async Task ChangePasswordAsync()
    {
        if (string.IsNullOrEmpty(OldPassword) || string.IsNullOrEmpty(NewPassword))
        {
            ErrorMessage = "Saisissez l'ancien et le nouveau mot de passe.";
            return;
        }

        await RunAsync(async () =>
        {
            await _users.ChangePasswordAsync(new ChangePasswordDto { OldPassword = OldPassword, NewPassword = NewPassword });
            OldPassword = "";
            NewPassword = "";
            await AlertAsync("Mot de passe", "Mot de passe modifie.");
        });
    }

    [RelayCommand]
    private async Task LogoutAsync()
    {
        _auth.Logout();
        ((AppShell)Shell.Current).ApplyRole(false);
        await Shell.Current.GoToAsync("//login");
    }

    private void Apply(UserDto me)
    {
        Email = me.Email;
        FirstName = me.FirstName;
        LastName = me.LastName;
        PhoneNumber = me.PhoneNumber ?? "";
        RoleLabel = me.RoleLabel;
        CreatedAt = me.CreatedAt.ToLocalTime().ToString("dd/MM/yyyy");
    }
}
