using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using GestionUtilisateurs.Mobile.Services;

namespace GestionUtilisateurs.Mobile.ViewModels;

public partial class LoginViewModel : BaseViewModel
{
    private readonly AuthService _auth;
    private readonly UserService _users;

    [ObservableProperty] private string email = "";
    [ObservableProperty] private string password = "";

    public LoginViewModel(AuthService auth, UserService users)
    {
        _auth = auth;
        _users = users;
    }

    [RelayCommand]
    private async Task LoginAsync()
    {
        if (string.IsNullOrWhiteSpace(Email) || string.IsNullOrEmpty(Password))
        {
            ErrorMessage = "Saisissez votre e-mail et votre mot de passe.";
            return;
        }

        await RunAsync(async () =>
        {
            await _auth.LoginAsync(Email, Password);
            Password = "";
            await EnterAppAsync();
        });
    }

    [RelayCommand]
    private Task GoToRegisterAsync() => Shell.Current.GoToAsync("register");

    /// <summary>Au demarrage : si un jeton valide est present, la session est restauree sans nouvelle saisie.</summary>
    public async Task TryRestoreSessionAsync()
    {
        if (IsBusy || !await _auth.HasSessionAsync()) return;
        await RunAsync(EnterAppAsync);
    }

    private async Task EnterAppAsync()
    {
        var me = await _users.GetMeAsync();
        ((AppShell)Shell.Current).ApplyRole(me.IsAdmin);
        await Shell.Current.GoToAsync("//main");
    }
}
