using CommunityToolkit.Mvvm.ComponentModel;
using GestionUtilisateurs.Mobile.Services;

namespace GestionUtilisateurs.Mobile.ViewModels;

public partial class BaseViewModel : ObservableObject
{
    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(IsNotBusy))]
    private bool isBusy;

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(HasError))]
    private string errorMessage = "";

    public bool IsNotBusy => !IsBusy;
    public bool HasError => !string.IsNullOrEmpty(ErrorMessage);

    /// <summary>Execute une action en gerant l'indicateur d'occupation et l'affichage des erreurs.</summary>
    protected async Task RunAsync(Func<Task> action)
    {
        if (IsBusy) return;

        IsBusy = true;
        ErrorMessage = "";
        try
        {
            await action();
        }
        catch (ApiException ex)
        {
            ErrorMessage = ex.Message;
        }
        catch (Exception)
        {
            ErrorMessage = "Une erreur inattendue est survenue.";
        }
        finally
        {
            IsBusy = false;
        }
    }

    protected static Task AlertAsync(string title, string message)
        => Shell.Current.DisplayAlert(title, message, "OK");
}
