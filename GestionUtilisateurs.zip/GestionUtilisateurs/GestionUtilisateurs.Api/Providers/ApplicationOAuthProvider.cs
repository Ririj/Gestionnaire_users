using System.Collections.Generic;
using System.Threading.Tasks;
using GestionUtilisateurs.Api.Managers;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.OAuth;

namespace GestionUtilisateurs.Api.Providers
{
    /// <summary>
    /// Valide les identifiants au point d'entree /Token et emet le jeton Bearer.
    /// </summary>
    public class ApplicationOAuthProvider : OAuthAuthorizationServerProvider
    {
        public override Task ValidateClientAuthentication(OAuthValidateClientAuthenticationContext context)
        {
            context.Validated();
            return Task.FromResult<object>(null);
        }

        public override async Task GrantResourceOwnerCredentials(OAuthGrantResourceOwnerCredentialsContext context)
        {
            var userManager = context.OwinContext.GetUserManager<ApplicationUserManager>();

            var user = await userManager.FindByNameAsync(context.UserName);
            if (user == null)
            {
                context.SetError("invalid_grant", "E-mail ou mot de passe incorrect.");
                return;
            }

            if (await userManager.IsLockedOutAsync(user.Id))
            {
                context.SetError("invalid_grant", "Compte verrouille temporairement apres trop d'echecs. Reessayez dans quelques minutes.");
                return;
            }

            if (!await userManager.CheckPasswordAsync(user, context.Password))
            {
                await userManager.AccessFailedAsync(user.Id);
                context.SetError("invalid_grant", "E-mail ou mot de passe incorrect.");
                return;
            }

            await userManager.ResetAccessFailedCountAsync(user.Id);

            var identity = await user.GenerateUserIdentityAsync(userManager, OAuthDefaults.AuthenticationType);
            var properties = new AuthenticationProperties(new Dictionary<string, string>
            {
                { "userName", user.UserName }
            });

            context.Validated(new AuthenticationTicket(identity, properties));
        }

        public override Task TokenEndpoint(OAuthTokenEndpointContext context)
        {
            foreach (var property in context.Properties.Dictionary)
            {
                context.AdditionalResponseParameters.Add(property.Key, property.Value);
            }
            return Task.FromResult<object>(null);
        }
    }
}
