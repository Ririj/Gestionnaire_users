using System.Data.Entity;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;

namespace GestionUtilisateurs.Api.Models
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public const string AdminRole = "Admin";
        public const string DefaultAdminEmail = "admin@gestion.local";
        public const string DefaultAdminPassword = "Admin12345";

        public ApplicationDbContext() : base("DefaultConnection", throwIfV1Schema: false)
        {
        }

        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext();
        }
    }

    /// <summary>
    /// Cree la base au premier lancement et ajoute le role Admin et un compte administrateur.
    /// </summary>
    public class ApplicationDbInitializer : CreateDatabaseIfNotExists<ApplicationDbContext>
    {
        protected override void Seed(ApplicationDbContext context)
        {
            var roleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(context));
            if (!roleManager.RoleExists(ApplicationDbContext.AdminRole))
            {
                roleManager.Create(new IdentityRole(ApplicationDbContext.AdminRole));
            }

            var userManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(context));
            if (userManager.FindByName(ApplicationDbContext.DefaultAdminEmail) == null)
            {
                var admin = new ApplicationUser
                {
                    UserName = ApplicationDbContext.DefaultAdminEmail,
                    Email = ApplicationDbContext.DefaultAdminEmail,
                    FirstName = "Administrateur",
                    LastName = "Systeme",
                    EmailConfirmed = true
                };
                var result = userManager.Create(admin, ApplicationDbContext.DefaultAdminPassword);
                if (result.Succeeded)
                {
                    userManager.AddToRole(admin.Id, ApplicationDbContext.AdminRole);
                }
            }

            base.Seed(context);
        }
    }
}
