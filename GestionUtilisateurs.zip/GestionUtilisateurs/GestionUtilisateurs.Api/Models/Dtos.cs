using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace GestionUtilisateurs.Api.Models
{
    // Transfer Objects : seuls ces types circulent entre l'API et le client mobile.

    public class RegisterDto
    {
        [Required(ErrorMessage = "L'e-mail est obligatoire."), EmailAddress(ErrorMessage = "E-mail invalide.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Le mot de passe est obligatoire.")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Le prenom est obligatoire."), StringLength(60)]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Le nom est obligatoire."), StringLength(60)]
        public string LastName { get; set; }

        [StringLength(30)]
        public string PhoneNumber { get; set; }
    }

    public class UserDto
    {
        public string Id { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime CreatedAt { get; set; }
        public List<string> Roles { get; set; } = new List<string>();
        public bool IsAdmin { get; set; }
    }

    public class CreateUserDto : RegisterDto
    {
        public bool IsAdmin { get; set; }
    }

    public class UpdateUserDto
    {
        [Required(ErrorMessage = "L'e-mail est obligatoire."), EmailAddress(ErrorMessage = "E-mail invalide.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Le prenom est obligatoire."), StringLength(60)]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Le nom est obligatoire."), StringLength(60)]
        public string LastName { get; set; }

        [StringLength(30)]
        public string PhoneNumber { get; set; }

        public bool IsAdmin { get; set; }
    }

    public class UpdateProfileDto
    {
        [Required(ErrorMessage = "Le prenom est obligatoire."), StringLength(60)]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Le nom est obligatoire."), StringLength(60)]
        public string LastName { get; set; }

        [StringLength(30)]
        public string PhoneNumber { get; set; }
    }

    public class ChangePasswordDto
    {
        [Required(ErrorMessage = "L'ancien mot de passe est obligatoire.")]
        public string OldPassword { get; set; }

        [Required(ErrorMessage = "Le nouveau mot de passe est obligatoire.")]
        public string NewPassword { get; set; }
    }
}
