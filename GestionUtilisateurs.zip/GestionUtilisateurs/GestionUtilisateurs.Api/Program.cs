using System;
using System.Data.Entity;
using System.Net;
using GestionUtilisateurs.Api.Models;
using Microsoft.Owin.Hosting;

namespace GestionUtilisateurs.Api
{
    internal static class Program
    {
        private static int Main(string[] args)
        {
            // "+" : ecoute sur toutes les interfaces, necessaire pour l'emulateur Android (10.0.2.2).
            var url = args.Length > 0 ? args[0] : "http://+:5000/";

            Database.SetInitializer(new ApplicationDbInitializer());
            try
            {
                using (var context = ApplicationDbContext.Create())
                {
                    context.Database.Initialize(force: false);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Impossible d'initialiser la base de donnees :");
                Console.WriteLine(ex.GetBaseException().Message);
                Console.WriteLine("Verifiez la chaine de connexion dans app.config (LocalDB / SQL Server).");
                return 1;
            }

            try
            {
                using (WebApp.Start<Startup>(url))
                {
                    Console.WriteLine("API demarree sur " + url);
                    Console.WriteLine("Compte administrateur : " + ApplicationDbContext.DefaultAdminEmail
                                      + " / " + ApplicationDbContext.DefaultAdminPassword);
                    Console.WriteLine("Appuyez sur Entree pour arreter.");
                    Console.ReadLine();
                }
            }
            catch (Exception ex) when (ex.GetBaseException() is HttpListenerException)
            {
                Console.WriteLine("Acces refuse pour l'adresse " + url);
                Console.WriteLine("Lancez une fois, dans une invite de commandes administrateur :");
                Console.WriteLine("  netsh http add urlacl url=http://+:5000/ user=Everyone");
                Console.WriteLine("ou demarrez l'application en administrateur, ou passez une adresse en argument :");
                Console.WriteLine("  GestionUtilisateurs.Api.exe http://localhost:5000/");
                return 1;
            }

            return 0;
        }
    }
}
