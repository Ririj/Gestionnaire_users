using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GestionUtilisateurs.Api.Managers;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;

namespace GestionUtilisateurs.Api.Controllers
{
    public abstract class BaseApiController : ApiController
    {
        private ApplicationUserManager _userManager;
        private UserDataManager _dataManager;

        /// <summary>UserManager de la requete courante, resolu depuis le contexte OWIN.</summary>
        protected ApplicationUserManager UserManager
        {
            get { return _userManager ?? (_userManager = Request.GetOwinContext().GetUserManager<ApplicationUserManager>()); }
        }

        protected UserDataManager DataManager
        {
            get { return _dataManager ?? (_dataManager = new UserDataManager(UserManager)); }
        }

        protected string CurrentUserId
        {
            get { return User.Identity.GetUserId(); }
        }

        protected IHttpActionResult Error(HttpStatusCode status, string message)
        {
            return Content(status, new { message });
        }

        protected IHttpActionResult InvalidModel()
        {
            var first = ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => string.IsNullOrEmpty(e.ErrorMessage) ? "Donnees invalides." : e.ErrorMessage)
                .FirstOrDefault();
            return Error(HttpStatusCode.BadRequest, first ?? "Donnees invalides.");
        }

        protected IHttpActionResult IdentityError(IdentityResult result)
        {
            return Error(HttpStatusCode.BadRequest, string.Join(" ", result.Errors));
        }
    }
}
