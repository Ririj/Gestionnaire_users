using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using GestionUtilisateurs.Api.Models;

namespace GestionUtilisateurs.Api.Controllers
{
    [RoutePrefix("api/account")]
    public class AccountController : BaseApiController
    {
        // POST api/account/register
        [AllowAnonymous]
        [HttpPost, Route("register")]
        public async Task<IHttpActionResult> Register(RegisterDto dto)
        {
            if (dto == null || !ModelState.IsValid) return InvalidModel();

            var result = await DataManager.RegisterAsync(dto);
            if (!result.Succeeded) return IdentityError(result);

            return Content(HttpStatusCode.Created, new { message = "Compte cree." });
        }

        // GET api/account/me
        [Authorize]
        [HttpGet, Route("me")]
        public async Task<IHttpActionResult> GetMe()
        {
            var me = await DataManager.GetAsync(CurrentUserId);
            if (me == null) return Error(HttpStatusCode.NotFound, "Utilisateur introuvable.");
            return Ok(me);
        }

        // PUT api/account/me
        [Authorize]
        [HttpPut, Route("me")]
        public async Task<IHttpActionResult> UpdateMe(UpdateProfileDto dto)
        {
            if (dto == null || !ModelState.IsValid) return InvalidModel();

            var result = await DataManager.UpdateProfileAsync(CurrentUserId, dto);
            if (!result.Succeeded) return IdentityError(result);

            return Ok(await DataManager.GetAsync(CurrentUserId));
        }

        // POST api/account/changePassword
        [Authorize]
        [HttpPost, Route("changePassword")]
        public async Task<IHttpActionResult> ChangePassword(ChangePasswordDto dto)
        {
            if (dto == null || !ModelState.IsValid) return InvalidModel();

            var result = await DataManager.ChangePasswordAsync(CurrentUserId, dto);
            if (!result.Succeeded) return IdentityError(result);

            return Ok(new { message = "Mot de passe modifie." });
        }
    }
}
