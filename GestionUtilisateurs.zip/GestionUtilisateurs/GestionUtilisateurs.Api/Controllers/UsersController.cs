using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using GestionUtilisateurs.Api.Models;

namespace GestionUtilisateurs.Api.Controllers
{
    /// <summary>CRUD complet des utilisateurs, reserve au role Admin.</summary>
    [Authorize(Roles = ApplicationDbContext.AdminRole)]
    [RoutePrefix("api/users")]
    public class UsersController : BaseApiController
    {
        // GET api/users
        [HttpGet, Route("")]
        public async Task<IHttpActionResult> GetAll()
        {
            return Ok(await DataManager.ListAsync());
        }

        // GET api/users/{id}
        [HttpGet, Route("{id}")]
        public async Task<IHttpActionResult> GetById(string id)
        {
            var user = await DataManager.GetAsync(id);
            if (user == null) return Error(HttpStatusCode.NotFound, "Utilisateur introuvable.");
            return Ok(user);
        }

        // POST api/users
        [HttpPost, Route("")]
        public async Task<IHttpActionResult> Create(CreateUserDto dto)
        {
            if (dto == null || !ModelState.IsValid) return InvalidModel();

            var result = await DataManager.RegisterAsync(dto, dto.IsAdmin);
            if (!result.Succeeded) return IdentityError(result);

            var created = await UserManager.FindByNameAsync(dto.Email);
            return Content(HttpStatusCode.Created, await DataManager.GetAsync(created.Id));
        }

        // PUT api/users/{id}
        [HttpPut, Route("{id}")]
        public async Task<IHttpActionResult> Update(string id, UpdateUserDto dto)
        {
            if (dto == null || !ModelState.IsValid) return InvalidModel();

            if (id == CurrentUserId && !dto.IsAdmin)
                return Error(HttpStatusCode.BadRequest, "Vous ne pouvez pas retirer votre propre role administrateur.");

            var result = await DataManager.UpdateAsync(id, dto);
            if (!result.Succeeded) return IdentityError(result);

            return Ok(await DataManager.GetAsync(id));
        }

        // DELETE api/users/{id}
        [HttpDelete, Route("{id}")]
        public async Task<IHttpActionResult> Delete(string id)
        {
            if (id == CurrentUserId)
                return Error(HttpStatusCode.BadRequest, "Vous ne pouvez pas supprimer votre propre compte.");

            var result = await DataManager.DeleteAsync(id);
            if (!result.Succeeded) return IdentityError(result);

            return Ok(new { message = "Utilisateur supprime." });
        }
    }
}
