using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using GestionUtilisateurs.Api.Models;
using Microsoft.AspNet.Identity;

namespace GestionUtilisateurs.Api.Managers
{
    /// <summary>
    /// Gestionnaire de donnees : regroupe les operations sur les utilisateurs et convertit
    /// les entites en Transfer Objects. Les controleurs n'utilisent jamais ApplicationUser directement.
    /// </summary>
    public class UserDataManager
    {
        private readonly ApplicationUserManager _userManager;

        public UserDataManager(ApplicationUserManager userManager)
        {
            _userManager = userManager;
        }

        public async Task<UserDto> ToDtoAsync(ApplicationUser user)
        {
            var roles = await _userManager.GetRolesAsync(user.Id);
            return new UserDto
            {
                Id = user.Id,
                Email = user.Email,
                FirstName = user.FirstName,
                LastName = user.LastName,
                PhoneNumber = user.PhoneNumber,
                CreatedAt = user.CreatedAt,
                Roles = roles.ToList(),
                IsAdmin = roles.Contains(ApplicationDbContext.AdminRole)
            };
        }

        public async Task<List<UserDto>> ListAsync()
        {
            var users = await _userManager.Users.OrderBy(u => u.LastName).ThenBy(u => u.FirstName).ToListAsync();
            var result = new List<UserDto>();
            foreach (var user in users)
            {
                result.Add(await ToDtoAsync(user));
            }
            return result;
        }

        public async Task<UserDto> GetAsync(string id)
        {
            var user = await _userManager.FindByIdAsync(id);
            return user == null ? null : await ToDtoAsync(user);
        }

        public async Task<IdentityResult> RegisterAsync(RegisterDto dto, bool isAdmin = false)
        {
            var user = new ApplicationUser
            {
                UserName = dto.Email,
                Email = dto.Email,
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                PhoneNumber = dto.PhoneNumber
            };

            var result = await _userManager.CreateAsync(user, dto.Password);
            if (result.Succeeded && isAdmin)
            {
                result = await _userManager.AddToRoleAsync(user.Id, ApplicationDbContext.AdminRole);
            }
            return result;
        }

        public async Task<IdentityResult> UpdateProfileAsync(string id, UpdateProfileDto dto)
        {
            var user = await _userManager.FindByIdAsync(id);
            if (user == null) return IdentityResult.Failed("Utilisateur introuvable.");

            user.FirstName = dto.FirstName;
            user.LastName = dto.LastName;
            user.PhoneNumber = dto.PhoneNumber;
            return await _userManager.UpdateAsync(user);
        }

        public async Task<IdentityResult> UpdateAsync(string id, UpdateUserDto dto)
        {
            var user = await _userManager.FindByIdAsync(id);
            if (user == null) return IdentityResult.Failed("Utilisateur introuvable.");

            user.UserName = dto.Email;
            user.Email = dto.Email;
            user.FirstName = dto.FirstName;
            user.LastName = dto.LastName;
            user.PhoneNumber = dto.PhoneNumber;

            var result = await _userManager.UpdateAsync(user);
            if (!result.Succeeded) return result;

            var isAdminNow = await _userManager.IsInRoleAsync(id, ApplicationDbContext.AdminRole);
            if (dto.IsAdmin && !isAdminNow)
                return await _userManager.AddToRoleAsync(id, ApplicationDbContext.AdminRole);
            if (!dto.IsAdmin && isAdminNow)
                return await _userManager.RemoveFromRoleAsync(id, ApplicationDbContext.AdminRole);

            return result;
        }

        public async Task<IdentityResult> DeleteAsync(string id)
        {
            var user = await _userManager.FindByIdAsync(id);
            if (user == null) return IdentityResult.Failed("Utilisateur introuvable.");
            return await _userManager.DeleteAsync(user);
        }

        public Task<IdentityResult> ChangePasswordAsync(string id, ChangePasswordDto dto)
        {
            return _userManager.ChangePasswordAsync(id, dto.OldPassword, dto.NewPassword);
        }
    }
}
