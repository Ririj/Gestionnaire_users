# Gestion des Utilisateurs

Application mobile (.NET MAUI, Android) et API (ASP.NET Web API 2, OWIN, ASP.NET Identity) de gestion de comptes utilisateurs.

## Contenu de la solution

| Projet | Rôle |
|---|---|
| `GestionUtilisateurs.Api` | API REST en .NET Framework 4.8, hébergée par OWIN (Katana) |
| `GestionUtilisateurs.Mobile` | Client .NET MAUI (Android), architecture MVVM |

## Fonctionnement

**API**
- `ApplicationUserManager` (hérite de `UserManager<ApplicationUser>`) est créé à chaque requête par `app.CreatePerOwinContext(...)` dans `Startup.cs`, puis récupéré dans les contrôleurs avec `Request.GetOwinContext().GetUserManager<ApplicationUserManager>()` (`Controllers/BaseApiController.cs`).
- Authentification OAuth2 par jeton Bearer sur `/Token` (`Providers/ApplicationOAuthProvider.cs`), avec verrouillage du compte après 5 échecs.
- `Managers/UserDataManager.cs` regroupe les opérations sur les utilisateurs et convertit les entités en DTO (`Models/Dtos.cs`).
- Un compte administrateur est créé au premier lancement : `admin@gestion.local` / `Admin12345`.

| Route | Accès | Description |
|---|---|---|
| `POST /Token` | public | connexion (`grant_type=password`) |
| `POST api/account/register` | public | inscription |
| `GET / PUT api/account/me` | connecté | consulter / modifier son profil |
| `POST api/account/changePassword` | connecté | changer son mot de passe |
| `GET / POST api/users` | Admin | lister / créer |
| `GET / PUT / DELETE api/users/{id}` | Admin | lire / modifier / supprimer |

**Application mobile**
- Le jeton est enregistré dans le `SecureStorage` et relu au démarrage : la session est restaurée tant qu'il n'a pas expiré.
- Une réponse 401 ramène automatiquement à l'écran de connexion.
- Un utilisateur simple voit son profil ; un administrateur voit aussi l'onglet « Utilisateurs » (CRUD).

## Prérequis

- Windows 10/11, Visual Studio 2022 avec les charges de travail « Développement .NET Multiplateforme (MAUI) » et « ASP.NET et développement web »
- SQL Server LocalDB (installé avec Visual Studio)
- Un émulateur Android (ou un téléphone en mode développeur)

## Lancer le projet

1. Cloner le dépôt, puis ouvrir `GestionUtilisateurs.sln`.
2. Autoriser une fois l'écoute réseau de l'API (invite de commandes **administrateur**) :
   ```
   netsh http add urlacl url=http://+:5000/ user=Everyone
   ```
3. Démarrer `GestionUtilisateurs.Api` (clic droit > Définir comme projet de démarrage > F5). Les packages NuGet sont restaurés automatiquement et la base `GestionUtilisateursDb` est créée au premier lancement. La console doit afficher `API démarrée sur http://+:5000/`.
4. Démarrer `GestionUtilisateurs.Mobile` sur un émulateur Android. L'émulateur joint l'API via `10.0.2.2:5000`.
5. Se connecter avec le compte administrateur ci-dessus, ou créer un compte depuis l'écran d'inscription.

En ligne de commande : `dotnet restore`, puis `dotnet build -t:Run -f net8.0-android` dans `GestionUtilisateurs.Mobile`.

## Configuration

- Chaîne de connexion : `GestionUtilisateurs.Api/app.config`.
- Adresse de l'API côté mobile : `GestionUtilisateurs.Mobile/Services/ApiConfig.cs`. Pour un téléphone physique, remplacer l'adresse par l'IP du PC sur le réseau local et autoriser le port 5000 dans le pare-feu Windows.
- Le trafic HTTP en clair n'est autorisé que pour le développement (`usesCleartextTraffic` dans `AndroidManifest.xml`, `AllowInsecureHttp` dans `Startup.cs`). En production, utiliser HTTPS.
